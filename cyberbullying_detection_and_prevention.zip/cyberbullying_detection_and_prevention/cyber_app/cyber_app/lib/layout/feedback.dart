import 'package:flutter/material.dart';
class feedback extends StatefulWidget {
  const feedback({super.key});

  @override
  State<feedback> createState() => _feedbackState();
}

class _feedbackState extends State<feedback> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: SingleChildScrollView(
            child: Column(children: [
              Container(
                padding: EdgeInsets.fromLTRB(90, 0, 90, 0),
                child: TextFormField(
                  decoration: InputDecoration(
                      labelText: "Feedback",
                      hintText: "feedback",
                      prefixIcon: Icon( Icons.comment),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20)
                      )

                  ) ,
                ),
              )

            ],),
          ),
        ),
      ),
    );
  }
}
