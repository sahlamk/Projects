import 'package:flutter/material.dart';
class friend extends StatefulWidget {
  const friend({super.key});

  @override
  State<friend> createState() => _friendState();
}

class _friendState extends State<friend> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: SingleChildScrollView(
            child: Column(children: [
              Container(
                padding: EdgeInsets.fromLTRB(90, 0, 90, 0),
                child: TextFormField(
                  decoration: InputDecoration(
                      labelText: "Add Friend",
                      hintText: "addfriend",
                      prefixIcon: Icon( Icons.comment),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20)
                      )

                  ) ,
                ),
              )

            ],),
          ),
        ),
      ),
    );
  }
}