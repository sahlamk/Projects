import 'package:flutter/material.dart';
class comment extends StatefulWidget {
  const comment({super.key});

  @override
  State<comment> createState() => _commentState();
}

class _commentState extends State<comment> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: SingleChildScrollView(
            child: Column(children: [
              Container(
                padding: EdgeInsets.fromLTRB(90, 0, 90, 0),
                child: TextFormField(
                  decoration: InputDecoration(
                    labelText: "Comment",
                    hintText: "comment",
                    prefixIcon: Icon( Icons.comment),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20)
                    )
                    
                  ) ,
                ),
              )

            ],),
          ),
        ),
      ),
    );
  }
}
