import 'package:flutter/material.dart';
class view_comment extends StatefulWidget {
  const view_comment({super.key});

  @override
  State<view_comment> createState() => _view_commentState();
}

class _view_commentState extends State<view_comment> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: SingleChildScrollView(
            child: Column(children: [
              Container(
                padding: EdgeInsets.fromLTRB(90, 0, 90, 0),
                child: TextFormField(
                  decoration: InputDecoration(
                      labelText: "View Comment",
                      hintText: "viewcomment",
                      prefixIcon: Icon( Icons.comment),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20)
                      )

                  ) ,
                ),
              )

            ],),
          ),
        ),
      ),
    );
  }
}
