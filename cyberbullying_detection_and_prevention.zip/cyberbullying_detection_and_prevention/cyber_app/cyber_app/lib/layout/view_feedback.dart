import 'package:flutter/material.dart';
class view_feedback extends StatefulWidget {
  const view_feedback({super.key});

  @override
  State<view_feedback> createState() => _view_feedbackState();
}

class _view_feedbackState extends State<view_feedback> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: SingleChildScrollView(
            child: Column(children: [
              Container(
                padding: EdgeInsets.fromLTRB(90, 0, 90, 0),
                child: TextFormField(
                  decoration: InputDecoration(
                      labelText: "View Feedback",
                      hintText: "viewfeedback",
                      prefixIcon: Icon( Icons.comment),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20)
                      )

                  ) ,
                ),
              )

            ],),
          ),
        ),
      ),
    );
  }
}
