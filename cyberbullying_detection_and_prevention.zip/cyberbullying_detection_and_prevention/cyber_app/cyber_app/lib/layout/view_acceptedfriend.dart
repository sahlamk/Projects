import 'package:flutter/material.dart';
class view_acceptedfriend extends StatefulWidget {
  const view_acceptedfriend({super.key});

  @override
  State<view_acceptedfriend> createState() => _view_acceptedfriendState();
}

class _view_acceptedfriendState extends State<view_acceptedfriend> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: SingleChildScrollView(
            child: Column(children: [
              Container(
                padding: EdgeInsets.fromLTRB(90, 0, 90, 0),
                child: TextFormField(
                  decoration: InputDecoration(
                      labelText: "Accept Friend",
                      hintText: "acceptfriend",
                      prefixIcon: Icon( Icons.comment),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20)
                      )

                  ) ,
                ),
              )

            ],),
          ),
        ),
      ),
    );
  }
}
