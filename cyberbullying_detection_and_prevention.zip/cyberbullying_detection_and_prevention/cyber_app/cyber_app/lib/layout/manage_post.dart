import 'package:flutter/material.dart';

class manage_post extends StatefulWidget {
  const manage_post({super.key});

  @override
  State<manage_post> createState() => _manage_postState();
}

class _manage_postState extends State<manage_post> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: SingleChildScrollView(
            child: Column(children: [

            ],),
          ),
        ),
      ),
    );
  }
}