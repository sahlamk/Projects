from django.http import HttpResponse
from django.shortcuts import render
from feedback.models import Feedback
import datetime
# Create your views here.
def postfeedback(request):
    if request.method == 'POST':
        obj = Feedback()
        obj.feedback = request.POST.get('feedback')
        obj.date = datetime.datetime.today()
        obj.time = datetime.datetime.now()
        obj.user_id = 1
        obj.save()
    return render(request, 'feedback/postfeedback.html')

def viewfeedback(request):
    obj = Feedback.objects.all()
    context = {
        'd': obj
    }
    return render(request, 'feedback/view_feedback.html', context)

from rest_framework.views import APIView,Response
from feedback.serializers import android_serialiser
class post_feedback(APIView):
    def post(self, request):
        obj = Feedback()
        obj.feedback = request.data['feedback']
        obj.date = datetime.datetime.today()
        obj.time = datetime.datetime.now()
        obj.user_id = 1
        obj.save()
        return HttpResponse('yes')

class view_feedback(APIView):
    def view(self, request):
        obj = Feedback.objects.all()
        ser = android_serialiser(obj, many=True)
        return Response(ser.data)