from django.conf.urls import url
from feedback import views

urlpatterns = [
    url('postfeedback/', views.postfeedback),
    url('viewfeedback/', views.viewfeedback),
    url('post_feedback/', views.post_feedback.as_view()),
    url('view_feedback/', views.view_feedback.as_view())

]