from django.db import models

# Create your models here.


class Alert(models.Model):
    alert_id = models.AutoField(primary_key=True)
    date = models.DateField()
    time = models.TimeField()
    alert = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'alert'
