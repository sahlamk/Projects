from django.conf.urls import url
from complaint import views

urlpatterns = [
    url('postcomplaint/', views.postcomplaint),
    url('postreply/', views.postreply),
    url('viewcomplaint/', views.viewcomplaint),
    url('viewreply/', views.viewcomplaint),
    url('reply/(?P<idd>\w+)',views.reply),
    url('post_complaint/',views.post_complaint.as_view()),
    url('view_complaint/',views.view_complaint.as_view())
]