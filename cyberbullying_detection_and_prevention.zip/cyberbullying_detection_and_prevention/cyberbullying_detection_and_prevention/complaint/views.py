from django.http import HttpResponse
from django.shortcuts import render
from complaint.models import Complaint
import datetime
# Create your views here.
def postcomplaint(request):
    if request.method == 'POST':
        obj = Complaint()
        obj.complaint = request.POST.get('complaint')
        obj.date = datetime.datetime.today()
        obj.time = datetime.datetime.now()
        obj.user_id=1
        obj.save()
    return render(request, 'complaint/postcomplaint.html')

def postreply(request):
    if request.method == 'POST':
        obj = Complaint()
        obj.reply= request.POST.get('reply')
        obj.user_id = 1
        obj.date =datetime.datetime.today()
        obj.time=datetime.datetime.now()
        obj.save()

    return render(request, 'complaint/postreply.html')

def viewcomplaint(request):
    obj = Complaint.objects.all()
    context = {
        'b': obj
    }
    return render(request, 'complaint/view_complaint.html', context)


def viewreply(request):
    obj = Complaint.objects.all()
    context = {
        'c': obj
    }
    return render(request, 'complaint/view_reply.html', context)
def reply(request,idd):
    if request.method=='POST':
        obj = Complaint.objects.get(complaint_id=idd)
        obj.reply = request.POST.get('reply')
        obj.save()
        return viewcomplaint(request)

    return  render(request,'complaint/postreply.html')

from rest_framework.views import APIView,Response
from complaint.serializers import android_serialiser
class post_complaint(APIView):
    def post(self, request):
        obj = Complaint()
        obj.complaint = request.data['complaint']
        obj.date = datetime.datetime.today()
        obj.time = datetime.datetime.now()
        obj.user_id = 1
        obj.save()
        return HttpResponse('yes')

class view_complaint(APIView):
    def view(self, request):
        obj = Complaint.objects.all()
        ser = android_serialiser(obj, many=True)
        return Response(ser.data)