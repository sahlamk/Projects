from django.http import HttpResponseRedirect
from django.shortcuts import render
# Create your views here.
from login.models import Login


def login(request):
    if request.method == 'POST':
        user_name = request.POST.get("un")
        password = request.POST.get("psw")
        obj=Login.objects.filter(username=user_name, password=password)
        type=""
        for ob in obj:
            type=ob.type
            uid=ob.u_id
            if type == "admin":
                request.session["u_id"]=uid
                return HttpResponseRedirect('/temp/admin/')
            else:
                objlist = "incorrect username or password................please try again"
                context = {
                    "msg" : objlist,
                }
            return render(request,'login/login.html',context)
    return render(request, 'login/login.html')

