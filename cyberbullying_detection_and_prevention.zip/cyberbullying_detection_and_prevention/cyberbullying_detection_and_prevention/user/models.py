from django.db import models

# Create your models here.
class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)
    gender = models.CharField(max_length=45)
    age = models.IntegerField()
    email = models.CharField(max_length=45)
    contactnumber = models.IntegerField()
    password = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'user'
