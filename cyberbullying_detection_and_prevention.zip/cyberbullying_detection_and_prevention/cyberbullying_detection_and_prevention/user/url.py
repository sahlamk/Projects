from django.conf.urls import url
from user import views

urlpatterns = [
    url('update/', views.update),
    url('userregister/', views.userregister),
    url('user/',views.user.as_view()),
]