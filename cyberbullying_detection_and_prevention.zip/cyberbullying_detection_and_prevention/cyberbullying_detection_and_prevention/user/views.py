from django.http import HttpResponse
from django.shortcuts import render
from user.models import User
# Create your views here.
def update(request):
    if request.method == 'POST':
        obj = User()
        obj.name = request.POST.get('name')
        obj.age= request.POST.get('age')
        obj.gender = request.POST.get('gender')
        obj.email = request.POST.get('email')
        obj.password = request.POST.get('psw')
        obj.contactnumber = request.POST.get('number')
        obj.save()
    return render(request, 'user/update.html')

def userregister(request):
    if request.method == 'POST':
        obj = User()
        obj.name = request.POST.get('name')
        obj.age = request.POST.get('age')
        obj.gender = request.POST.get('gender')
        obj.email = request.POST.get('email')
        obj.password = request.POST.get('psw')
        obj.contactnumber = request.POST.get('number')
        obj.save()
    return render(request, 'user/userregister.html')

from rest_framework.views import APIView,Response
from user.serializers import android_serialiser
class user(APIView):
    def post(self, request):
        obj = User
        obj.name = request.data('name')
        obj.age = request.data('age')
        obj.gender = request.data('gender')
        obj.email = request.data('email')
        obj.password = request.data('psw')
        obj.contactnumber = request.data('number')
        obj.save()
        return HttpResponse('yes')
