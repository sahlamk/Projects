from django.shortcuts import render
from comment.models import Comment
from django.http import HttpResponse
import datetime
# Create your views here.
def addcomment(request):
    if request.method =='POST':
        obj = Comment()
        obj.comment = request.POST.get('comment')
        obj.date = datetime.datetime.today()
        obj.time = datetime.datetime.now()
        obj.user_id = 1
        obj.save()
    return render(request, 'comment/addcomment.html')

def viewcomment(request):
    obj = Comment.objects.all()
    context = {
        'a': obj
    }
    return render(request, 'comment/view_comment.html', context)

from rest_framework.views import APIView,Response
from comment.serializers import android_serialiser





class post_comment(APIView):
    def post(self, request):
        obj = Comment()
        obj.comment = request.data['comment']
        obj.date = datetime.datetime.today()
        obj.time = datetime.datetime.now()
        obj.user_id = 1
        obj.save()
        return HttpResponse('yes')
class view_cmnt(APIView):
    def view(self, request):
        obj = Comment.objects.all()
        ser = android_serialiser(obj, many=True)
        return Response(ser.data)