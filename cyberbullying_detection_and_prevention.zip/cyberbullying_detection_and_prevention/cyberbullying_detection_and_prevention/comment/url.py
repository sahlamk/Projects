from django.conf.urls import url
from comment import views

urlpatterns = [
    url('addcooment/', views.addcomment),
    url('viewcomment/', views.viewcomment),
    url('post_cmnt/',views.post_comment.as_view()),
    url('view_cmnt/',views.view_cmnt.as_view())
]