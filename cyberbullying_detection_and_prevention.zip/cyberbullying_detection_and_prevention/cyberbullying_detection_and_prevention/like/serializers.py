from rest_framework import serializers
from like.models import Like

class android_serialiser(serializers.ModelSerializer):
    class Meta:
        model = Like
        fields='__all__'