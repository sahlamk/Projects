from django.conf.urls import url
from like import views

urlpatterns = [
    url('addlike/', views.addlike),
    url('addlike/',views.add_like.as_view()),

]