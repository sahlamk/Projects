from django.http import HttpResponse
from django.shortcuts import render
from like.models import Like
# Create your views here.
def addlike(request):
    if request.method == 'POST':
        obj = Like()
        obj.like = request.POST.get('like')
        obj.save()
    return render(request, 'like/addlike.html')

from rest_framework.views import APIView,Response
from like.serializers import android_serialiser

class add_like(APIView):
    def post(self, request):
        obj = Like()
        obj.like = request.data['like']
        obj.save()
        return HttpResponse('yes')