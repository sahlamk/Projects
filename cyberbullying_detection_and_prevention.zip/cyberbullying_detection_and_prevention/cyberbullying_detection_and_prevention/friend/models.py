from django.db import models
from user.models import  User
# Create your models here.
class Friend(models.Model):
    friend_id = models.AutoField(primary_key=True)
    friend = models.CharField(max_length=45)
    status = models.CharField(max_length=45)
    # user_id = models.IntegerField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'friend'
