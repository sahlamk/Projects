from django.http import HttpResponse
from django.shortcuts import render
from friend.models import Friend
# Create your views here.
def addfriend(request):
    if request.method == 'POST':
        obj = Friend()
        obj.friend = request.POST.get('friend')
        obj.user_id=1
        obj.save()
    return render(request, 'friend/addfriend.html')

def viewacceptedfriend(request):
    obj = Friend.objects.all()
    context = {
        'e': obj
    }
    return render(request, 'friend/view_accepted friend.html', context)

def viewandaddfriend(request):
    obj = Friend.objects.all()
    context = {
        'f': obj
    }
    return render(request, 'friend/view_andaddfriend.html', context)

from rest_framework.views import APIView,Response
from feedback.serializers import android_serialiser

class add_friend(APIView):
    def post(self, request):
        obj = Friend()
        obj.friend = request.data['friend']
        obj.user_id = 1
        obj.save()
        return HttpResponse('yes')
class view_addfriend(APIView):
    def view(self, request):
        obj = Friend.objects.all()
        ser = android_serialiser(obj, many=True)
        return Response(ser.data)
class view_acceptedfriend(APIView):
    def view(self, request):
        obj = Friend.objects.all()
        ser = android_serialiser(obj, many=True)
        return Response(ser.data)