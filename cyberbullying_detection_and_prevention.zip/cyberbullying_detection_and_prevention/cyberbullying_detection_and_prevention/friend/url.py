from django.conf.urls import url
from friend import views

urlpatterns = [
    url('addfriend/', views.addfriend),
    url('viewacceptedfriend/', views.viewacceptedfriend),
    url('viewandaddfriend/', views.viewandaddfriend),
    url('aadd_friend/',views.add_friend.as_view()),
    url('view_addfriend/',views.view_addfriend.as_view()),
    url('view_acceptedfriend/',views.view_acceptedfriend.as_view())

]