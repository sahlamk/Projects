from rest_framework import serializers
from friend.models import Friend

class android_serialiser(serializers.ModelSerializer):
    class Meta:
        model = Friend
        fields='__all__'