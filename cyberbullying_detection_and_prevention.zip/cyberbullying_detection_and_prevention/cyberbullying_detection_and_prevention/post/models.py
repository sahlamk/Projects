from django.db import models
from user.models import  User
# Create your models here.
class Post(models.Model):
    post_id = models.AutoField(primary_key=True)
    post = models.CharField(max_length=45)
    date = models.DateField()
    tme = models.TimeField()
    status = models.CharField(max_length=45)
    # user_id = models.IntegerField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'post'
