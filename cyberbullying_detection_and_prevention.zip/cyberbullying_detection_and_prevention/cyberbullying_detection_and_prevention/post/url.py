from django.conf.urls import url
from post import views

urlpatterns = [
    url('addpost/', views.addpost),
    url('viewandmanagepost/', views.viewandmanagepost),
    url('approve/(?P<idd>\w+)',views.approve),
    url('rejected/(?P<idd>\w+)',views.rejected),
    url('view_addfriend/',views.add_post.as_view()),
    url('view_managepost/',views.view_managepost.as_view())
]