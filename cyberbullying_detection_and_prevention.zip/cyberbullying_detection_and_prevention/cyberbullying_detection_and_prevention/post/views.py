from django.http import HttpResponse
from django.shortcuts import render
from post.models import Post
import datetime
# Create your views here.
def addpost(request):
    if request.method == 'POST':
        obj = Post()
        obj.user_id=1
        obj.post = request.POST.get('post')
        obj.date = datetime.datetime.today()
        obj.tme = datetime.datetime.now()
        obj.status='pending'
        obj.save()
    return render(request, 'post/addpost.html')

def viewandmanagepost(request):
    obj = Post.objects.all()
    context = {
        'g': obj
    }
    return render(request, 'post/view_andmanagepost.html',context)

def approve(request,idd):
    obj=Post.objects.get(post_id=idd)
    obj.status='approve'
    obj.save()
    return  viewandmanagepost(request)
def rejected(request,idd):
    obj=Post.objects.get(post_id=idd)
    obj.status='rejected'
    obj.save()
    return  viewandmanagepost(request)

from rest_framework.views import APIView,Response
from post.serializers import android_serialiser

class add_post(APIView):
    def post(self, request):
        obj = Post()
        obj.post = request.data['post']
        obj.date = datetime.datetime.today()
        obj.time = datetime.datetime.now()
        obj.user_id = 1
        obj.status = 'pending'
        obj.save()
        return HttpResponse('yes')

class view_managepost(APIView):
    def view(self, request):
        obj = Post.objects.all()
        ser = android_serialiser(obj, many=True)
        return Response(ser.data)
